/*
  Developer: Huroye Scott
  Client: Spark Digital
  Date: 9/6/2020  - first created
        9/8/2020  - updated

*/
package movies.analysis

import org.apache.log4j.{Level, LogManager}
import org.apache.spark.sql.DataFrame

object moviesAnalysis {
	import movies.datapreparation.DataPrep
	import movies.sessionmanagement.MovieSession

	def main(args: Array[String]): Unit = {
		//limit console logging
		LogManager.getLogger("org").setLevel(Level.ERROR)
		LogManager.getLogger("akka").setLevel(Level.ERROR)
		val movieSession: MovieSession= new MovieSession
		val dataPrep: DataPrep = new DataPrep

		val mData = dataPrep.movieData(movieSession)

		//1.	Which actor, with all their movies combined, has the highest average imdb score?
		println("Q1: Which actor, with all their movies combined, has the highest average imdb score?")
		val highestAverageImdbScore = imdbScoreByActor(movieSession, mData)
		highestAverageImdbScore.withColumnRenamed("ave_imdb_score","highest_avg_imdb_score").show(false)

		//2.	Which director has the movie with the highest imdb score?
		println("Q2: Which director has the movie with the highest imdb score?")
		val highestMovieImdbScoreByDirector = imdbScoreByDirector(movieSession)
		highestMovieImdbScoreByDirector.withColumnRenamed("imdb_score","highest_imdb_score").dropDuplicates().show(false)

		//3.	Which movie features actors with the most facebook likes?
		println("Q3: Which movie features actors with the most facebook likes?")
		val mostFBLikes = mostFBLikesByActor(movieSession)
		mostFBLikes.show(false)

		//4.	What is the average imdb rating for all actors that have been in more than 3 movies?
		println("Q4: What is the average imdb rating for all actors that have been in more than 3 movies?")
		val actorsAveImdbRating = avgIimdbScoreAllActors(movieSession)
		actorsAveImdbRating.show(false)

		//5.	Which genre of movie has the second highest average rating?
		println("Q5: Which genre of movie has the second highest average rating?")
		val movieGereRating = genreAveRating(movieSession)
		movieGereRating.show(false)



		movieSession.spark().stop()
	}//main()
	def imdbScoreByActor(movieSession: MovieSession, data: DataFrame): DataFrame = {
		data.createOrReplaceTempView("vw_MovieData")
		//get all averages
		val  avgImdbScore = movieSession.spark().sql(
			"SELECT actor_id," +
				"actor_name, " +
				"ROUND(AVG(imdb_score),2) as avg_imdb_score  " +
				"FROM vw_MovieData  GROUP BY actor_id, actor_name " +
				"ORDER BY actor_id")
		avgImdbScore.createOrReplaceTempView("vw_aveScore")

		val  highestAvgImdbScore = movieSession.spark().sql("SELECT * FROM vw_aveScore WHERE avg_imdb_score =  " +
			" (SELECT max(avg_imdb_score) FROM vw_aveScore)")

		highestAvgImdbScore
	}//imdbScoreByActor()

	def imdbScoreByDirector(movieSession: MovieSession): DataFrame = {

		//get all director movies scores
		val highestImdbScore = movieSession.spark().sql(
			"SELECT director_id," +
				"director_name, " +
				"movie_id,"+
				"movie_title,"+
				"imdb_score " +
				"FROM vw_MovieData WHERE imdb_score = (SELECT max(imdb_score) FROM vw_MovieData )" )

		highestImdbScore

	}//imdbScoreByDirector()
	def mostFBLikesByActor(movieSession: MovieSession): DataFrame = {

		//get all averages
		val  fbLikes = movieSession.spark().sql(
			"SELECT  movie_id,movie_title, " +
				"actor_facebook_likes , SUM(actor_facebook_likes) OVER(PARTITION BY movie_title ORDER BY actor_facebook_likes ) sum_of_fb_likes " +
				"FROM vw_MovieData"
		)
		fbLikes.createOrReplaceTempView("mostFBLikes")

		val mostFKLikesActors = movieSession.spark().sql(
			"SELECT  movie_id, movie_title , ROUND(sum_of_fb_likes) as total_fb_likes " +
				"FROM mostFBLikes WHERE sum_of_fb_likes = (SELECT MAX(sum_of_fb_likes) FROM mostFBLikes)"
		)
		mostFKLikesActors
	}//mostFBLikesByActor()

	def avgIimdbScoreAllActors(movieSession: MovieSession): DataFrame = {

		//get actors who have been in more than 3 movies
		val actorsList = movieSession.spark().sql("SELECT actor_id, actor_name,imdb_score, COUNT(movie_id) movie_participation_cnt FROM vw_MovieData  GROUP BY actor_id, actor_name,imdb_score" )
		actorsList.createOrReplaceTempView("grt3MoviesActors")

		//get the average imdb_rating for selected actors
		val  avgImdbRating = movieSession.spark().sql(
			"SELECT " +
				"actor_name, " +
				"ROUND(AVG(imdb_score),2) as avg_imdb_rating  " +
				"FROM grt3MoviesActors WHERE movie_participation_cnt > 3 " +
				"GROUP BY actor_id, actor_name  ORDER BY actor_name").dropDuplicates()
		avgImdbRating.createOrReplaceTempView("aveForAll_Actors")

		/*	If you want to get the overAll average/GrandAverage
			val grandAverage = spark.sql("SELECT ROUND(AVG(avg_imdb_rating),2) actors_ave_imbd_rating FROM aveForAll_Actors")
			grandAverage
		*/
		avgImdbRating
	}//avgIimdbScoreAllActors()

	//get the average for all the genres
	def genreAveRating(movieSession: MovieSession): DataFrame ={
		val movieGenre = movieSession.spark().sql("SELECT  genres, ROUND(AVG(imdb_score),2) ave_imdb_score FROM vw_MovieData GROUP BY genres ORDER BY ave_imdb_score DESC LIMIT 2" ).dropDuplicates()
		movieGenre.createOrReplaceTempView("aveImdbScore")

		//get the second highest average
		val genres2HighestAve = movieSession.spark().sql("SELECT  max(ave_imdb_score) second_highest_average_rating  FROM aveImdbScore  " +
			"WHERE ave_imdb_score < (SELECT  max(ave_imdb_score)  FROM aveImdbScore)")

		genres2HighestAve
	}//genreAveRating()

}//moviesAnalysis()
