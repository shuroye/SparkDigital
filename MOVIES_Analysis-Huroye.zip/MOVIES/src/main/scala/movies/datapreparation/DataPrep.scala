package movies.datapreparation

import org.apache.spark.sql.DataFrame

class DataPrep() {

	def movieData(movieSession: movies.sessionmanagement.MovieSession): DataFrame = {

		//change the path to where you will put the data files before running this code
		val filePath = "C:\\MOVIES\\data\\"

		val movies_df = movieSession.spark().read.format("csv").option("header", "true").load(filePath + "movies.csv")
			.withColumnRenamed("id", "movie_id")
			.withColumnRenamed("created_at","movie_create_dt")
			.withColumnRenamed("updated_at", "movie_update_dt").cache()

		val actors_df = movieSession.spark().read.format("csv").option("header", "true").load(filePath + "actors.csv")
			.withColumnRenamed("id", "actor_id")
			.withColumnRenamed("facebook_likes","actor_facebook_likes")
			.withColumnRenamed("name", "actor_name")
			.withColumnRenamed("created_at","actor_create_dt")
			.withColumnRenamed("updated_at", "actor_update_dt")

		val directors_df = movieSession.spark().read.format("csv").option("header", "true").load(filePath + "directors.csv")
			.withColumnRenamed("id", "director_id")
			.withColumnRenamed("name", "director_name")
			.withColumnRenamed("created_at","director_create_dt")
			.withColumnRenamed("updated_at", "director_update_dt").cache()

		val studio_df = movieSession.spark().read.format("csv").option("header", "true").load(filePath + "studios.csv")
			.withColumnRenamed("id", "studio_id")
			.withColumnRenamed("studio","studio_name").cache()

		//create data views
		movies_df.createOrReplaceTempView("vw_movies_df")
		actors_df.createOrReplaceTempView("vw_actors_df")
		directors_df.createOrReplaceTempView("vw_directors_df")
		studio_df.createOrReplaceTempView("vw_studio_df")

		/*Integrating the data. since the input  data was pivoted it needed to be restructure to make the analysis
		easier
		*/
		val actor_1_Data = movieSession.spark().sql(
			"SELECT " +
				"m.actor_1_id as actor_id," +
				"a.actor_name," +
				"COALESCE(actor_facebook_likes, 0 ) AS actor_facebook_likes,"+
				"d.director_id,"+
				"d.director_name,"+
				"COALESCE(director_facebook_likes, 0 ) AS director_facebook_likes,"+
				"s.studio_id,"+
				"s.studio_name,"+
				"m.movie_id,"+
				"m.movie_title,"+
				"m.title_year,"+
				"m.genres,"+
				"m.imdb_score,"+
				"m.duration,"+
				"m.gross,"+
				"m.plot_keywords"+
				"  FROM vw_movies_df m, vw_actors_df a, vw_directors_df d, vw_studio_df s" +
				"  WHERE m.actor_1_id  = a.actor_id  " +
				"  AND  m.director_id  = d.director_id AND m.studio_id = s.studio_id AND a.actor_name IS NOT NULL " +
				"  ORDER BY a.actor_id"
		)

		val actor_2_Data = movieSession.spark().sql(
			"SELECT " +
				"m.actor_2_id as actor_id," +
				"a.actor_name," +
				"COALESCE(actor_facebook_likes, 0 ) AS actor_facebook_likes,"+
				"d.director_id,"+
				"d.director_name,"+
				"COALESCE(director_facebook_likes, 0 ) AS director_facebook_likes,"+
				"s.studio_id,"+
				"s.studio_name,"+
				"m.movie_id,"+
				"m.movie_title,"+
				"m.title_year,"+
				"m.genres,"+
				"m.imdb_score,"+
				"m.duration,"+
				"m.gross,"+
				"m.plot_keywords"+
				"  FROM vw_movies_df m, vw_actors_df a, vw_directors_df d, vw_studio_df s" +
				"  WHERE m.actor_2_id  = a.actor_id  " +
				"  AND  m.director_id  = d.director_id AND m.studio_id = s.studio_id AND a.actor_name IS NOT NULL " +
				"  ORDER BY a.actor_id"
		)
		val actor_3_Data = movieSession.spark().sql(
			"SELECT " +
				"m.actor_3_id as actor_id," +
				"a.actor_name," +
				"COALESCE(actor_facebook_likes, 0 ) AS actor_facebook_likes,"+
				"d.director_id,"+
				"d.director_name,"+
				"COALESCE(director_facebook_likes, 0 ) AS director_facebook_likes,"+
				"s.studio_id,"+
				"s.studio_name,"+
				"m.movie_id,"+
				"m.movie_title,"+
				"m.title_year,"+
				"m.genres,"+
				"m.imdb_score,"+
				"m.duration,"+
				"m.gross,"+
				"m.plot_keywords"+
				"  FROM vw_movies_df m, vw_actors_df a, vw_directors_df d, vw_studio_df s" +
				"  WHERE m.actor_3_id  = a.actor_id  " +
				"  AND  m.director_id  = d.director_id AND m.studio_id = s.studio_id  AND a.actor_name IS NOT NULL " +
				"  ORDER BY a.actor_id"
		)
		//combine/integrate the various segments of actors (1,2,3) data
		val integretedData = actor_1_Data.union(actor_2_Data).union(actor_3_Data).toDF()

		integretedData
	}//movieData()
}
