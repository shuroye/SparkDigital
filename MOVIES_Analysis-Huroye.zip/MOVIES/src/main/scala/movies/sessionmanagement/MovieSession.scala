package movies.sessionmanagement
import org.apache.spark.sql.SparkSession
class MovieSession {

	def spark(): SparkSession = {
		val spark: SparkSession = SparkSession.builder()
			.appName("MoviesAnalysis")
			.master("local[*]")
			.getOrCreate()
		spark
	}
}
