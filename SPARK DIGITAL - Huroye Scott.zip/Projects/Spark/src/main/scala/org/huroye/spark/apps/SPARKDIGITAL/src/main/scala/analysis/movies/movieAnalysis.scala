/*
  Developed by Huroye Scott
  Purpose: Interview assessment from Spark Digital
  Date: 9/6/2020
*/

package analysis.movies

import org.apache.log4j.{Level, LogManager}
import org.apache.spark.sql.{DataFrame, SparkSession}

object movieAnalysis {
	def main(args: Array[String]): Unit = {
		//limit console logging
		 LogManager.getLogger("org").setLevel(Level.WARN)
		LogManager.getLogger("akka").setLevel(Level.WARN)

    //create Spark Session
		val sparkSession = SparkSession.builder()
			.appName("Movie Analysis")
			.master("local[*]")
			.getOrCreate()

		//make the data globally available for all def's
		val mData = movieData(sparkSession)
		mData.createOrReplaceTempView("vw_MovieData")


		/**
		    Analysis - please note that results are sent to the console
		 */

			//1.	Which actor, with all their movies combined, has the highest average imdb score?
		  val highestAverageImdbScore = imdbScoreByActor(sparkSession)
		  highestAverageImdbScore.withColumnRenamed("ave_imdb_score","highest_avg_imdb_score").show(false)

		  //2.	Which director has the movie with the highest imdb score?
		  val highestMovieImdbScoreByDirector = imdbScoreByDirector(sparkSession)
		  highestMovieImdbScoreByDirector.withColumnRenamed("imdb_score","highest_imdb_score").dropDuplicates().show(false)

		//3.	Which movie features actors with the most facebook likes?
      val mostFBLikes = mostFBLikesByActor(sparkSession)
		  mostFBLikes.show(false)

		//4.	What is the average imdb rating for all actors that have been in more than 3 movies?
		 val actorsAveImdbRating = avgIimdbScoreAllActors(sparkSession)
		 actorsAveImdbRating.show(false)

		//5.	Which genre of movie has the second highest average rating?
     val movieGereRating = genreAveRating(sparkSession)
		 movieGereRating.show(false)

		 sparkSession.stop()//close the session
	}//main

	def imdbScoreByActor(spark: SparkSession): DataFrame = {

		//get all averages
		val  avgImdbScore = spark.sql(
			"SELECT actor_id," +
				"actor_name, " +
				"ROUND(AVG(imdb_score),2) as avg_imdb_score  " +
				"FROM vw_MovieData  GROUP BY actor_id, actor_name " +
				"ORDER BY actor_id")
		avgImdbScore.createOrReplaceTempView("vw_aveScore")

		 val  highestAvgImdbScore = spark.sql("SELECT * FROM vw_aveScore WHERE avg_imdb_score =  " +
		 " (SELECT max(avg_imdb_score) FROM vw_aveScore)")

		highestAvgImdbScore
	}//imdbScoreByActor()
	def imdbScoreByDirector(spark: SparkSession): DataFrame = {

		//get all director movies scores
		val highestImdbScore = spark.sql(
			"SELECT director_id," +
				"director_name, " +
				"movie_id,"+
				"movie_title,"+
				"imdb_score " +
				"FROM vw_MovieData WHERE imdb_score = (SELECT max(imdb_score) FROM vw_MovieData )" )

		highestImdbScore

	}//imdbScoreByDirector()
	def mostFBLikesByActor(spark: SparkSession): DataFrame = {

		//get all averages
		val  fbLikes = spark.sql(
			"SELECT  movie_id,movie_title, " +
				"actor_facebook_likes , SUM(actor_facebook_likes) OVER(PARTITION BY movie_title ORDER BY actor_facebook_likes ) sum_of_fb_likes " +
				"FROM vw_MovieData where movie_id = '52e43fd89db54696a154ba6b70935fb4'"
		)
		fbLikes.createOrReplaceTempView("mostFBLikes")

		val mostFKLikesActors = spark.sql(
			"SELECT  movie_id, movie_title , ROUND(sum_of_fb_likes) as total_fb_likes " +
				"FROM mostFBLikes WHERE sum_of_fb_likes = (SELECT MAX(sum_of_fb_likes) FROM mostFBLikes)"
		)
		mostFKLikesActors
	}//mostFBLikesByActor()

	def avgIimdbScoreAllActors(spark: SparkSession): DataFrame = {

		//get actors who have been in more than 3 movies
		val actorsList = spark.sql("SELECT actor_id, actor_name,imdb_score, COUNT(movie_id) movie_participation_cnt FROM vw_MovieData  GROUP BY actor_id, actor_name,imdb_score" )
		actorsList.createOrReplaceTempView("grt3MoviesActors")

		//get the average imdb_rating for selected actors
		val  avgImdbRating = spark.sql(
			"SELECT " +
				"actor_name, " +
				"ROUND(AVG(imdb_score),2) as avg_imdb_rating  " +
				"FROM grt3MoviesActors WHERE movie_participation_cnt > 3 " +
				"GROUP BY actor_id, actor_name  ORDER BY actor_name").dropDuplicates()
		avgImdbRating.createOrReplaceTempView("aveForAll_Actors")

	/*	If you want to get the overAll average/GrandAverage
		val grandAverage = spark.sql("SELECT ROUND(AVG(avg_imdb_rating),2) actors_ave_imbd_rating FROM aveForAll_Actors")
		grandAverage
  */
		avgImdbRating
	}//avgIimdbScoreAllActors()

	  //get the average for all the genres
	  def genreAveRating(spark:SparkSession): DataFrame ={
			val movieGenre = spark.sql("SELECT  genres, ROUND(AVG(imdb_score),2) ave_imdb_score FROM vw_MovieData GROUP BY genres ORDER BY ave_imdb_score DESC LIMIT 2" ).dropDuplicates()
			movieGenre.createOrReplaceTempView("aveImdbScore")

			//get the second highest average
			val genres2HighestAve = spark.sql("SELECT  max(ave_imdb_score) second_highest_average_rating  FROM aveImdbScore  " +
				"WHERE ave_imdb_score < (SELECT  max(ave_imdb_score)  FROM aveImdbScore)")

			genres2HighestAve
		}//genreAveRating()

	  /*
	      Below here is my data collection and prep. Normally I will put this in a separate class and handle the general
	      rangling and quality of the data

	   */
		def movieData(spark: SparkSession): DataFrame = {
			//change the path to where you will put the data files before running this code
			val filePath = "C:\\Training\\INTERVIEWING\\SPARK-DIGITAL\\Data Engineer IMDB-20200822T132900Z-001\\Data Engineer IMDB\\"

			val movies_df = spark.read.format("csv").option("header", "true").load(filePath + "movies.csv")
				.withColumnRenamed("id", "movie_id")
				.withColumnRenamed("created_at","movie_create_dt")
				.withColumnRenamed("updated_at", "movie_update_dt").cache()

			val actors_df = spark.read.format("csv").option("header", "true").load(filePath + "actors.csv")
				.withColumnRenamed("id", "actor_id")
				.withColumnRenamed("facebook_likes","actor_facebook_likes")
  			.withColumnRenamed("name", "actor_name")
				.withColumnRenamed("created_at","actor_create_dt")
				.withColumnRenamed("updated_at", "actor_update_dt")

			val directors_df = spark.read.format("csv").option("header", "true").load(filePath + "directors.csv")
				.withColumnRenamed("id", "director_id")
  			.withColumnRenamed("name", "director_name")
  			.withColumnRenamed("created_at","director_create_dt")
  			.withColumnRenamed("updated_at", "director_update_dt").cache()

			val studio_df = spark.read.format("csv").option("header", "true").load(filePath + "studios.csv")
  			.withColumnRenamed("id", "studio_id")
  			.withColumnRenamed("studio","studio_name").cache()

			//create data views
			movies_df.createOrReplaceTempView("vw_movies_df")
			actors_df.createOrReplaceTempView("vw_actors_df")
			directors_df.createOrReplaceTempView("vw_directors_df")
			studio_df.createOrReplaceTempView("vw_studio_df")

			/*Integrating the data. since the input  data was pivoted it needed to be restructure to make the analysis
			easier
			*/
			val actor_1_Data = spark.sql(
				   "SELECT " +
						 "m.actor_1_id as actor_id," +
						 "a.actor_name," +
						 "COALESCE(actor_facebook_likes, 0 ) AS actor_facebook_likes,"+
						 "d.director_id,"+
						 "d.director_name,"+
						 "COALESCE(director_facebook_likes, 0 ) AS director_facebook_likes,"+
						 "s.studio_id,"+
						 "s.studio_name,"+
						 "m.movie_id,"+
						 "m.movie_title,"+
						 "m.title_year,"+
						 "m.genres,"+
						 "m.imdb_score,"+
						 "m.duration,"+
						 "m.gross,"+
						 "m.plot_keywords"+
						 "  FROM vw_movies_df m, vw_actors_df a, vw_directors_df d, vw_studio_df s" +
						 "  WHERE m.actor_1_id  = a.actor_id  " +
						 "  AND  m.director_id  = d.director_id AND m.studio_id = s.studio_id AND a.actor_name IS NOT NULL " +
						 "  ORDER BY a.actor_id"
			)

			val actor_2_Data = spark.sql(
				"SELECT " +
					"m.actor_2_id as actor_id," +
					"a.actor_name," +
					"COALESCE(actor_facebook_likes, 0 ) AS actor_facebook_likes,"+
					"d.director_id,"+
					"d.director_name,"+
					"COALESCE(director_facebook_likes, 0 ) AS director_facebook_likes,"+
					"s.studio_id,"+
					"s.studio_name,"+
					"m.movie_id,"+
					"m.movie_title,"+
					"m.title_year,"+
					"m.genres,"+
					"m.imdb_score,"+
					"m.duration,"+
					"m.gross,"+
					"m.plot_keywords"+
					"  FROM vw_movies_df m, vw_actors_df a, vw_directors_df d, vw_studio_df s" +
					"  WHERE m.actor_2_id  = a.actor_id  " +
					"  AND  m.director_id  = d.director_id AND m.studio_id = s.studio_id AND a.actor_name IS NOT NULL " +
					"  ORDER BY a.actor_id"
			)
			val actor_3_Data = spark.sql(
				"SELECT " +
					"m.actor_3_id as actor_id," +
					"a.actor_name," +
					"COALESCE(actor_facebook_likes, 0 ) AS actor_facebook_likes,"+
					"d.director_id,"+
					"d.director_name,"+
					"COALESCE(director_facebook_likes, 0 ) AS director_facebook_likes,"+
					"s.studio_id,"+
					"s.studio_name,"+
					"m.movie_id,"+
					"m.movie_title,"+
					"m.title_year,"+
					"m.genres,"+
					"m.imdb_score,"+
					"m.duration,"+
					"m.gross,"+
					"m.plot_keywords"+
					"  FROM vw_movies_df m, vw_actors_df a, vw_directors_df d, vw_studio_df s" +
					"  WHERE m.actor_3_id  = a.actor_id  " +
					"  AND  m.director_id  = d.director_id AND m.studio_id = s.studio_id  AND a.actor_name IS NOT NULL " +
					"  ORDER BY a.actor_id"
			)
			//combine/integrate the various segments of actors (1,2,3) data
			actor_1_Data.union(actor_2_Data).union(actor_3_Data).cache()

		}//movieData()

}//finale